# -*- coding: utf-8 -*-
"""
    constants.py
    :copyright: © 2019 by the EAB Tech team.
    :license: Apache License, Version 2.0, see LICENSE for more details.
"""

__version__ = '0.4.2'
